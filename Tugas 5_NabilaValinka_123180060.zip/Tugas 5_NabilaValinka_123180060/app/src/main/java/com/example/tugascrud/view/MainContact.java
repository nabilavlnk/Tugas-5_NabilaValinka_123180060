package com.example.tugascrud.view;

import android.view.View;

import com.example.tugascrud.entity.AppDatabase;
import com.example.tugascrud.entity.DataKampus;

import java.util.List;

public interface MainContact {
    interface view extends View.OnClickListener{
        void successAdd();
        void successDelete();
        void resetForm();
        void getData(List<DataKampus> list);
        void editData(DataKampus item);
        void deleteData(DataKampus item);
    }

    interface presenter{
        void insertData(String nama, String jenkel, String nim, String asal, AppDatabase database);
        void readData(AppDatabase database);
        void editData(String nama, String jenkel, String nim, String asal, int id, AppDatabase database);
        void deleteData(DataKampus dataKampus, AppDatabase appDatabase);

    }
}

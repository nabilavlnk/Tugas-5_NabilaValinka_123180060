package com.example.tugascrud.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tugascrud.R;
import com.example.tugascrud.entity.AppDatabase;
import com.example.tugascrud.entity.DataKampus;

import java.util.List;

public class MainActivity extends AppCompatActivity implements MainContact.view {
    private AppDatabase appDatabase;
    private MainPresenter mainPresenter;
    private MainAdapter mainAdapter;
    public static Context context;

    private Button submit;
    private RecyclerView recyclerView;
    private EditText etNama, etJenkel, etNim, etAsal;

    private int id = 0;
    boolean edit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        submit = findViewById(R.id.submit);
        etNama = findViewById(R.id.etNama);
        etJenkel = findViewById(R.id.etJenkel);
        etNim = findViewById(R.id.etNim);
        etAsal = findViewById(R.id.etAsal);
        recyclerView = findViewById(R.id.rc_main);

        appDatabase = AppDatabase.inidb(getApplicationContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mainPresenter = new MainPresenter(this);
        mainPresenter.readData(appDatabase);
        submit.setOnClickListener(this);
    }

    @Override
    public void successAdd() {
        Toast.makeText(this, "Berhasil", Toast.LENGTH_SHORT).show();
        mainPresenter.readData(appDatabase);
    }

    @Override
    public void successDelete() {
        Toast.makeText(this, "Berhasil Menghapus Data", Toast.LENGTH_SHORT).show();
        mainPresenter.readData(appDatabase);
    }

    @Override
    public void resetForm() {
        etNama.setText("");
        etJenkel.setText("");
        etNim.setText("");
        etAsal.setText("");
        submit.setText("Submit");
    }

    public void getData(List<DataKampus> list) {
        mainAdapter = new MainAdapter(this, list, this);
        recyclerView.setAdapter(mainAdapter);
    }

    public void editData(DataKampus item) {
        etNama.setText(item.getNama());
        etJenkel.setText(item.getJenkel());
        etNim.setText(item.getNim());
        etAsal.setText(item.getAsal());
        id = item.getId();
        edit = true;
        submit.setText("EDIT DATA");
    }

    @Override
    public void deleteData(DataKampus item) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle("Menghapus Data")
                .setMessage("Anda yakin ingin menghapus data ini?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        resetForm();
                        mainPresenter.deleteData(item, appDatabase);
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        dialogInterface.cancel();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_dialer)
                .show();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.submit) {
            if (etNama.getText().toString().equals("") || etJenkel.getText().toString().equals("") ||
                    etNim.getText().toString().equals("") || etAsal.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Harap isi Semua data", Toast.LENGTH_SHORT).show();
            } else {
                if (!edit) {
                    mainPresenter.insertData(etNama.getText().toString(), etJenkel.getText().toString(), etNim.getText().toString(),
                            etAsal.getText().toString(), appDatabase);
                } else {
                    mainPresenter.editData(etNama.getText().toString(), etJenkel.getText().toString(), etNim.getText().toString(),
                            etAsal.getText().toString(), id, appDatabase);
                    edit = false;
                }
                resetForm();
            }
        }
    }
}